Version: 1.5.1.SR2
Build Date: 20110705101717

* Sets Xmx to 1024M
* Sets MaxPermGen to 256M for Hotspot VMs
* Sets java.awt.headless to true
